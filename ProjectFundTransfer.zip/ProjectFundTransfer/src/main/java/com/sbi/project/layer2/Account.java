package com.sbi.project.layer2;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="project_applicant")
public class Account {

	@Id
	private Integer account_number;
	private String password;
	private Float balance;
	
	@OneToOne
	@JoinColumn(name="applicant_id")
	Applicant applicant;

}

