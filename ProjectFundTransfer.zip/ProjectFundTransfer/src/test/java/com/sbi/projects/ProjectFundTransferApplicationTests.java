package com.sbi.projects;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectFundTransferApplicationTests {

	@Test
	void contextLoads() {
	}

}
